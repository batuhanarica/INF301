//Omer Gizbili 12308674

#include "client.h"
#include <stdio.h>
#include <ctype.h>
#include <stdbool.h>
#include <string.h>

char reponse[MAXREP];

int find_num_declarage(char fl) {
    int num_declarage = 'C' - fl; 
    return num_declarage;
}


char encrypt_lettre(char c, int num_declarage) {
    if ('a' <= c && c <= 'z') {
        c = (char)(c + num_declarage);  
        if (c > 'z') {
            c -= 26;  
        }
    } else if ('A' <= c && c <= 'Z') {
        c = (char)(c + num_declarage);  
        if (c > 'Z') {
            c -= 26;
        }
    }
    return c;
}


char decrypt_lettre(char c, int num_declarage) {
    if ('a' <= c && c <= 'z') {
        c = (char)(c - num_declarage); 
        if (c < 'a') {
            c += 26;  
        }
    } else if ('A' <= c && c <= 'Z') {
        c = (char)(c - num_declarage);  
        if (c < 'A') {
            c += 26;
        }
    }
    return c;
}

void encrypt_message(char input[], char encrypted[], int num_declarage) {
    int i = 0;
    while (input[i] != '\0') {
        encrypted[i] = encrypt_lettre(input[i], num_declarage);  
        i++;
    }
    encrypted[i] = '\0';
}


int main() {
    show_messages(true);
    connexion("im2ag-appolab.u-ga.fr");
    envoyer("login 12308674 \"GIZBILI\"");
    envoyer("load planB");
    envoyer_recevoir("help", reponse);
    envoyer("start");
    char encrypted_message[MAXREP];
    strcpy(encrypted_message, reponse);
    int num_declarage = find_num_declarage(encrypted_message[0]);
    printf("Calculated num_declarage: %d\n", num_declarage);
    char message[] = "hasta la revolucion";
    char encrypted_message_to_send[MAXREP];
    encrypt_message(message, encrypted_message_to_send, num_declarage);
    envoyer(encrypted_message_to_send);
    deconnexion();
    printf("Fin de la connection au serveur\n");

    return 0;
}
