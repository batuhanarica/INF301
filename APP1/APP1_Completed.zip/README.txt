client-planB :Batuhan ARICA 
planB_2:Omer GIZBILI
OneMillion : -
LostCause :  -


#On aime bien les references au Cuba et Etats-Unis pour les sujets :)