#include "arbresphylo.h"
#include "arbres.h"
#include "listes.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void analyse_arbre(arbre racine, int *nb_esp, int *nb_carac)
{   
    static int is_root = 1;
    if(is_root){
        *nb_esp = 0 ;
        *nb_carac = 0;
        is_root = 0;
    }
    if(racine == NULL){ //O(1)
        return;//O(1)
    }
    if(racine->gauche == NULL && racine->droit == NULL){//O(1)
        (*nb_esp)++;//O(1)
    }
    else{//O(1)
        (*nb_carac)++;//O(1)
    }
    analyse_arbre(racine->gauche , nb_esp , nb_carac);//O(length_racine_gauche)
    analyse_arbre(racine->droit, nb_esp , nb_carac);//O(length_racine_droit)
    return;//O(1)
       
}

void calcul(arbre racine , int *x){
	if(racine == NULL){ //O(1)
        return;//O(1)
    }
    if(racine->gauche != NULL || racine->droit != NULL){//O(1)
        x++;
        calcul(racine->droit,x); //O(length_racine_droite)
        calcul(racine->gauche,x);//O(length_racine_gauche)
    }
}

int carac(arbre racine){
	int c = 0; //O(1)
	calcul(racine,&c); //O(n)
	return c;//O(1)
}



/* ACTE II */
/* Recherche l'espece dans l'arbre. Modifie la liste passée en paramètre pour y
 * mettre les caractéristiques. Retourne 0 si l'espèce a été retrouvée, 1 sinon.
 */
int rechercher_espece(arbre racine, char *espece, liste_t *seq)
{
    static int is_first = 1;//O(1)

    if(is_first){
        liberer_liste(seq);//O(length_seq)
        is_first = 0;//O(1)
    }
    
    if(racine == NULL){return 1;}//O(1)
    if((strcmp(racine->valeur,espece) == 0) && racine->droit == NULL && racine->gauche == NULL){//O(1)
        return 0;//O(1)
    }
   
    int d = rechercher_espece(racine->droit,espece,seq);//O(length_racine_droite)
    if(d == 0){//O(1)
       ajouter_tete(seq,racine->valeur);//O(1)
       return 0;//O(1)
    }
    
    int g = rechercher_espece(racine->gauche,espece,seq);//O(length_racine_gauche)
    return g;//O(1)
}


void ajouter_droite(arbre racine, char *nom){
	noeud *temp = racine;
    while (temp->droit != NULL) { //O(h), ou h est le longeur d'arbre
        temp = temp->droit;
    }
    temp->valeur = nom; //O(1)
}

void ajouter_gauche(arbre racine, char *nom){
	noeud *temp = racine;
    while (temp->gauche != NULL) { //O(h), ou h est le longeur d'arbre
        temp = temp->gauche;
    }
    temp->valeur = nom; //O(1)
}


/* Doit renvoyer 0 si l'espece a bien ete ajoutee, 1 sinon, et ecrire un
 * message d'erreur.
*/

int ajouter_espece(arbre *racine, char *espece, cellule_t *seq){
    printf("Debug:Debut function\n");//O(1)
    affiche_arbre((*racine));//O(n)
    /*
    1. if racine null and list null >> add the espece
    2. if racine null and list not null >> add the caracterestics and the espece at the end
    3. if racine not null and list null >> error
    4.last case
        i)first value == seq val : ajouter_espece(racine->droit, espece, seq->suiv)
        ii) ajouter_espece(racine->gauche, espece, seq)
    */

	if(*racine == NULL && seq == NULL){//O(1)
        printf("Debug:Racine et seq est NULL\n");//O(1)
		*racine = malloc(sizeof(arbre));//O(1)
		if(*racine == NULL ){//O(1)
			printf("Erreur : allocation memoire echouee\n");//O(1)
			return 1;//O(1)
		}
		(*racine)->valeur = espece; //O(1)
        (*racine)->gauche = NULL;//O(1)
        (*racine)->droit = NULL;//O(1)
        return 0;//O(1)
    }

    if (*racine != NULL && seq == NULL){ //O(1)
		printf("Ne peut ajouter %s: possède les mêmes caractères que %s.\n", espece, (*racine)->valeur);//O(1)
		return 1;//O(1)
	}



    if((*racine) == NULL && seq!= NULL){//O(1)
        *racine = malloc(sizeof(noeud));//O(1)
		if(*racine == NULL ){//O(1)
			printf("Erreur : allocation memoire echouee\n");//O(1)
			return 1;//O(1)
		}
		(*racine)->valeur = seq->val;//O(1) 
        (*racine)->gauche = NULL;//O(1)
        (*racine)->droit = NULL;//O(1)
        return ajouter_espece((&(*racine)->droit) ,espece,seq->suivant);//O(h)
    }


    if (strcmp((*racine)->valeur, seq->val) == 0){ //O(1)
		return ajouter_espece(&(*racine)->droit, espece, seq->suivant);//O(h)
	}

    if ((*racine) ->gauche ==  NULL && (*racine)->droit == NULL){//O(1)
		(*racine)->gauche = malloc(sizeof(arbre));//O(1)
		(*racine)->gauche->valeur = (*racine)->valeur;//O(1)
		(*racine)->valeur = seq->val;//O(1)
		(*racine)->droit = NULL;//O(1)
		return ajouter_espece(&(*racine)->droit, espece, seq->suivant);//O(h)
	}
	return ajouter_espece(&(*racine)->gauche, espece, seq);//O(h)

}

// Acte 4


int ajouter_carac(arbre *a, char *carac, cellule_t *seq){
    printf ("<<<<< À faire: fonction ajouter_carac fichier " __FILE__ " >>>>>\n");
    return 0;
}
